
package org.w3c.dom.svg;

public interface SVGAnimatedAngle {
  public SVGAngle getBaseVal( );
  public SVGAngle getAnimVal( );
}
