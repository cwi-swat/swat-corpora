
package org.w3c.dom.svg;

public interface SVGTextElement extends 
               SVGTextPositioningElement,
               SVGTransformable {
}
