
package org.w3c.dom.svg;

public interface SVGStopElement extends 
               SVGElement,
               SVGStylable {
  public SVGAnimatedNumber getOffset( );
}
