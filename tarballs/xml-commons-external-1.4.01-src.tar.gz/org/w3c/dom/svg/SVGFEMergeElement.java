
package org.w3c.dom.svg;

public interface SVGFEMergeElement extends 
               SVGElement,
               SVGFilterPrimitiveStandardAttributes {
}
